package com.example.api_volley.Util;

public class ServerAPI {
    public static final String URL_DATA = "http://192.168.246.107/Framework/Minggu11/CI/index.php/Mahasiswa/Api";
    public static final String URL_INSERT = "http://192.168.246.107/Framework/Minggu11/CI/index.php/Mahasiswa/ApiInsert";
    public static final String URL_DELETE = "http://192.168.246.107/Framework/Minggu11/CI/index.php/Mahasiswa/ApiDelete";
    public static final String URL_UPDATE = "http://192.168.246.107/Framework/Minggu11/CI/index.php/Mahasiswa/ApiUpdate";
}
